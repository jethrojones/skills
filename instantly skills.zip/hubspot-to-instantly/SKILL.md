---
name: hubspot-to-instantly
description: Move HubSpot contacts into an Instantly campaign — de-dupe against existing Instantly leads, reconcile verification status, move or upload, and attach custom variables that power template tags like {{School District}}. Use when handing a HubSpot CSV off to cold outreach (new prospects, new campaigns, or retargeting an existing audience into a new sequence).
---

# HubSpot → Instantly Transfer

Move a HubSpot CSV of contacts into an Instantly campaign, preserving verification status and attaching custom variables that power `{{tag}}` personalization in emails.

## When to use

- User exports contacts from HubSpot and wants them in an Instantly campaign
- User wants to move existing Instantly leads between campaigns (with updated custom fields)
- User references "HubSpot list" + "Instantly campaign" in the same breath

## Auth

```bash
INSTANTLY_KEY=$(cat ~/.config/instantly/api_key.txt)
# Instantly API BLOCKS default Python urllib UA via Cloudflare — set User-Agent: curl/8.0
```

## Standard fields to transfer

| Field | Default behavior | Instantly key |
|---|---|---|
| **HubSpot Record ID** | **ALWAYS include** — don't ask | `hubspot_record_id` |
| Email | Always — it's the lead key | `email` |
| First Name / Last Name | Always | `first_name` / `last_name` |
| School District (or Company name) | **Ask once per engagement** — column Q in NC exports is "Company name" (lowercase n, populated ~100%), K is "Company Name" (capital N, sparse). Verify which column is actually filled. Default target: `School District` custom var to power `{{School District}}` template tag | `School District` |
| Job Title | Ask once | stored as `jobTitle` (Instantly normalizes snake_case to camelCase) |
| Phone | Ask once | `phone` |
| State / City / Location | Ask once | `state`, `location` |

## Fields to ASK about (don't assume)

Ask the user which of these they want transferred. Any column in the HubSpot CSV can become a custom variable. Examples the user has considered:

- **Last meeting date** — useful for re-engagement sequences
- **Lead Status** — routing / segmentation
- **Contact owner** — assignment
- **Create Date / Last Activity Date** — recency signals
- **Trial Account ID** — product-led signals
- **Industry / Country**
- **Parent Company** — for district-level rollups
- Any custom HubSpot property

**Rule:** anything beyond email + name + HubSpot Record ID is opt-in. Surface the column list and ask which ones to carry over.

## Workflow

### 1. Inspect the CSV
```python
import csv
with open(csv_path) as f:
  r=csv.DictReader(f); headers=r.fieldnames; rows=list(r)
# Show headers, row count, sample values for each column
```

Warn the user about common HubSpot export gotchas:
- **Duplicate column names** with different case ("Company Name" vs "Company name") — the second usually wins for the company-level field. Verify which is populated.
- **Two `Create Date` columns** (contact + company) — drop one.
- **Phone formats vary** — HubSpot sends `+1...` and `(xxx)xxx-xxxx` inconsistently.

### 2. Pull existing Instantly leads and de-dupe

```python
# Paginate /api/v2/leads/list — REQUIRES include_email: true to get the email field in the response
# Cursor format: next_starting_after — can contain `&` and `@`, URL-encode with safe=''
import urllib.request, urllib.parse, json
HDRS={'Authorization': f'Bearer {KEY}', 'Content-Type':'application/json', 'User-Agent':'curl/8.0'}
all_leads=[]; cursor=None
while True:
  body={'limit':100,'include_email':True}
  if cursor: body['starting_after']=cursor
  r=urllib.request.Request('https://api.instantly.ai/api/v2/leads/list', data=json.dumps(body).encode(), headers=HDRS)
  d=json.loads(urllib.request.urlopen(r).read())
  all_leads.extend(d.get('items',[]))
  cursor=d.get('next_starting_after')
  if not cursor or not d.get('items'): break
```

Cross-reference CSV emails against Instantly emails (case-insensitive, trimmed). Produce:
- **Overlap** — already in Instantly (may need to be moved between campaigns)
- **New** — to upload fresh

Save both lists to `~/clawd/tmp/` (never `/tmp/`).

### 3. Report the scope before acting

Always surface to the user BEFORE any destructive action:

- Overlap count + current campaign distribution
- Verification status breakdown (`verification_status` codes):
  - `1` = Verified (safe to email)
  - `-1` = Invalid/bounced (exclude from moves — will hurt deliverability)
  - `null` = Unverified (flag, ask)
- Lead status distribution (`status` codes): `1`=Active, `3`=Completed, `-1`=Bounced
- Stragglers with no campaign assigned (special case — see below)
- Replied leads (use `email_reply_count > 0`) — preserve these carefully

### 4. Move existing leads between campaigns

`/api/v2/leads/move` requires a SOURCE filter (`campaign` or `list_id`) AND `to_campaign_id`:

```python
body={'ids':[...], 'campaign': SOURCE_CAMPAIGN_ID, 'to_campaign_id': DEST_CAMPAIGN_ID}
# POST /api/v2/leads/move — returns a background job
# Poll /api/v2/background-jobs/{job_id} until status='success'
```

Batching: 1,000+ IDs in a single call works fine.

### 5. Upload new leads

`POST /api/v2/leads` — one lead per call. Use threads (8 workers is a safe default):

```python
body={
  'campaign': CAMPAIGN_ID,
  'email': row['Email'],
  'first_name': row['First Name'],
  'last_name': row['Last Name'],
  'skip_if_in_workspace': True,   # Prevents duplicates if they already exist
  'skip_if_in_campaign': True,    # Prevents re-add if already in campaign
  'custom_variables': {
    'hubspot_record_id': row['Record ID - Contact'],   # Always
    'School District': row['School District'],          # Plus whatever else user picked
    # ... other opt-in fields
  }
}
```

### 6. Set custom variables on existing leads

`PATCH /api/v2/leads/{id}` with `custom_variables` — they land in the lead's `payload`:

```python
body={'custom_variables': {'hubspot_record_id': '...', 'School District': '...', 'job_title': '...'}}
```

**Quirks:**
- Instantly **silently normalizes** `job_title` → `jobTitle` (camelCase) in storage.
- **Keys with spaces are preserved literally** — `School District` stays `School District` (required for `{{School District}}` template tag to resolve).
- Other `payload` keys you send that Instantly doesn't recognize may be silently dropped — test with one lead first.
- PATCH response sometimes echoes values that weren't actually saved. **Always re-GET to verify.**

### 7. Straggler handling (leads in Instantly with no campaign)

Leads that exist in Instantly but have `campaign: null` **cannot be assigned to a campaign via API**:
- `/leads/move` rejects them (requires source campaign or list)
- PATCH `{campaign: '...'}` is silently ignored
- POST `/leads` either creates a duplicate or (with `skip_if_in_workspace: true`) returns the existing lead without moving it

**Ask the user before touching stragglers.** Options:
- **A:** Skip stragglers entirely — user adds them manually in UI
- **B:** Delete + re-create in target campaign (loses reply/engagement history — **dangerous if they have replies**)
- **C:** Re-create only the ones with zero reply/open/click history (split the baby)

**Default recommendation:** Flag any straggler with `email_reply_count > 0` and ask before destructive operations.

## Template tags reference

Instantly personalization syntax in email body:
- `{{firstName}}` `{{lastName}}` `{{companyName}}` — built-ins pulled from payload
- `{{School District}}` — custom variable, matches `payload["School District"]` exactly (case-sensitive, spaces preserved)
- `{{accountSignature}}` — sending mailbox's configured signature (NOT `{{signature}}` — that one the UI used to show but the real tag is `{{accountSignature}}`)

## Bulk delete

`DELETE /api/v2/leads` — bulk deletes leads from a campaign or list:
```python
body = {
    'campaign_id': CAMPAIGN_ID,  # required if list_id not provided
    'ids': [...],                # optional — specific lead IDs; omit to delete ALL matching
    'status': 3,                 # optional filter (1=active, 3=completed, -1=bounced)
    'limit': 100,                # optional; default = all matching (up to 10,000)
}
# Returns {"count": N}
```
**CRITICAL:** Omitting `ids` and `limit` deletes ALL leads in the campaign. Always pass `ids` or `limit` during exploration. Never use a real campaign_id when probing the endpoint — use a fake UUID.

Straggler leads (campaign=null) cannot be bulk-deleted — they have no campaign_id or list_id anchor. Delete them individually via `DELETE /leads/{id}`.

## Listing stragglers

`POST /api/v2/leads/list` accepts `in_campaign: false` to return only workspace leads not enrolled in any campaign:
```python
body = {'limit': 100, 'include_email': True, 'in_campaign': False}
```

## Critical gotchas (learned the hard way)

1. **Python urllib gets 403'd by Cloudflare.** Always set `User-Agent: curl/8.0` in headers.
2. **`/api/v2/leads/list` omits the `email` field by default.** Pass `include_email: true`.
3. **Valid timezones are a subset of IANA.** `America/New_York` is REJECTED. Use `America/Detroit` for Eastern (same offset + DST rules).
4. **Instantly UI may overwrite API changes** if the campaign page was open during the PATCH. Re-fetch to confirm.
5. **Verification status is numeric.** UI shows "Verified"; API returns `1`. The label mapping isn't exposed in the API.
6. **The built-in `companyName` and `jobTitle` fields auto-normalize.** Don't try to send them under other keys.
7. **Scratch files go in `~/clawd/tmp/`, not `/tmp/`.**

## What I don't need to ask about

- Always include `hubspot_record_id` as a custom variable
- Always de-dupe by email (case-insensitive, trimmed)
- Always exclude `verification_status = -1` (bounced) from campaign moves
- Always report scope + confirm before bulk moves >100 leads
- Always save intermediate data to `~/clawd/tmp/`

## What I must ask about

- Which Instantly campaign is the target (by name or ID)
- Which optional columns beyond name/email/record-ID to transfer as custom variables
- For stragglers with reply history: preserve vs. recreate
- Whether to also move existing overlap leads or only upload new ones
